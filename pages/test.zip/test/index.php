<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="mail.php" method="POST">
		<input type="email" name="email" placeholder="email">
		<input type="submit" name="submit" value="submit">
	</form>

</body>
</html>