<?php
define('EMAIL', 'g.ankit1213@gmail.com');
define('PASS', 'Ankitkumar');

?>
