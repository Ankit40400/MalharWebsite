<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Load Composer's autoloader


require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
require 'OAuth.php';
require 'emailpass.php';

// Instantiation and passing `true` enables exceptions
if(isset($_POST['submit']))
{  


$mail = new PHPMailer(true);

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$subject = $_POST['subject'];
$messsage = $_POST['message'];


    //Server settings
    //$mail->SMTPDebug = 4;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = EMAIL;                     // SMTP username
    $mail->Password   = PASS;                               // SMTP password
    $mail->SMTPSecure = 'ssl';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom(EMAIL, 'malhar test');
    $mail->addAddress(EMAIL);     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo($email);
    
   
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Malhar Website Contact Form Response';
    $mail->Body    ="The form was submitted with the following details\n\nName: " . $name . "\nEmail: " . $email . "\nPhone: " . $phone . "\nSubject: ". $subject . "\nMessage: " . $messsage . "\n\nEnd of message";

    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    if($mail->send()){  
       header("location:index.php?mes=true");
} else{
    header("laction:index.php?mes=false");
    
}


}
